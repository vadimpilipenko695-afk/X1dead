package com.example.fpsoverlay

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var running = true

    override fun onCreate() {
        super.onCreate()
        startForegroundServiceNotification()

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)

        val overlayType =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 20
        params.y = 100

        windowManager.addView(overlayView, params)
        makeDraggable()

        running = true
        Thread { fpsLoop() }.start()
    }

    // Позволяет перетаскивать плавающее окошко пальцем
    private fun makeDraggable() {
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        overlayView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun startForegroundServiceNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "fps_overlay_channel",
                "FPS Overlay",
                NotificationManager.IMPORTANCE_MIN
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)

            val notification: Notification = Notification.Builder(this, "fps_overlay_channel")
                .setContentTitle("FPS Overlay активен")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()

            startForeground(1, notification)
        }
    }

    // Выполняет команду через root (su) и возвращает вывод
    private fun runRootCommand(cmd: String): String {
        return try {
            val process = ProcessBuilder("su", "-c", cmd)
                .redirectErrorStream(true)
                .start()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            output
        } catch (e: Exception) {
            ""
        }
    }

    private fun getFocusedPackage(): String? {
        val out = runRootCommand("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        val regex = Regex("""([a-zA-Z0-9_.]+)/[a-zA-Z0-9_.$]+""")
        return regex.find(out)?.groupValues?.get(1)
    }

    private fun getWindowName(pkg: String): String? {
        val out = runRootCommand("dumpsys SurfaceFlinger --list | grep '$pkg' | tail -n 1")
        val line = out.trim()
        return if (line.isEmpty()) null else line
    }

    private fun getFrameCount(win: String): Int {
        val out = runRootCommand("dumpsys SurfaceFlinger --latency '$win'")
        val lines = out.trim().split("\n").drop(1)
        var count = 0
        for (line in lines) {
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size >= 2 && parts[1] != "0") count++
        }
        return count
    }

    private fun fpsLoop() {
        while (running) {
            try {
                val pkg = getFocusedPackage()
                var fps = 0
                if (pkg != null) {
                    val win = getWindowName(pkg)
                    if (win != null) {
                        val c1 = getFrameCount(win)
                        Thread.sleep(1000)
                        val c2 = getFrameCount(win)
                        fps = (c2 - c1).coerceAtLeast(0)
                    } else {
                        Thread.sleep(1000)
                    }
                } else {
                    Thread.sleep(1000)
                }

                val fpsFinal = fps
                handler.post {
                    overlayView.findViewById<TextView>(R.id.fpsText).text = "FPS: $fpsFinal"
                }
            } catch (e: Exception) {
                Thread.sleep(1000)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
